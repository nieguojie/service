# -*- coding: utf-8 -*-
NAME = 'salt-broker'
DESCRIPTION = 'A lightweight proxy for saltstack'
VERSION = '0.2.5'
AUTHOR = 'pengyao'
AUTHOR_EMAIL = 'pengyao@pengyao.org'
COPYRIGHT = 'Copyright © 2015 ' + AUTHOR
LICENCE = 'Apache License V2.0'
URL = 'https://github.com/pengyao/salt-broker'



